suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(tidyr)
})

phylogeny_dir <- "data/phylogeny"
harmonization_dir <- file.path(
  phylogeny_dir,
  "taxonomy_harmonization"
)
output_dir <- Sys.getenv(
  "HARMONIZED_OUTPUT_DIR",
  unset = file.path(
    harmonization_dir,
    "outputs",
    "final_sar11_165_iqtree_high_support"
  )
)

master_path <- file.path(phylogeny_dir, "subclade_master.tsv")
cat_path <- file.path(phylogeny_dir, "subclade_cat.tsv")
table_path <- file.path(phylogeny_dir, "subclade.txt")
tree_annotation_path <- file.path(
  phylogeny_dir,
  "tree",
  "tree_annottable_ogpage_542.tsv"
)
overview_summary_path <- file.path(
  "data",
  "overview",
  "genome_summary.tsv"
)
audit_path <- file.path(output_dir, "subclade_harmonized_audit.tsv")
validation_path <- file.path(
  output_dir,
  Sys.getenv(
    "HARMONIZED_VALIDATION_FILENAME",
    unset = "sar11_165_taxon_validation.tsv"
  )
)

taxonomy_columns <- c(
  "genome", "Clade1", "Clade2", "Subclade", "Subgroup",
  "Order", "Family", "Genus", "Species"
)

read_taxonomy <- function(path, table_name) {
  read_tsv(
    path,
    col_select = all_of(taxonomy_columns),
    col_types = cols(.default = col_character()),
    na = "NA",
    show_col_types = FALSE,
    progress = FALSE
  ) %>%
    mutate(table = table_name, .before = 1)
}

read_overview_taxonomy <- function(path) {
  read_tsv(
    path,
    col_select = c(
      genome_id, clade_1, clade_2, subclade, subgroup,
      Order, Family, Genus, Species
    ),
    col_types = cols(.default = col_character()),
    na = "NA",
    show_col_types = FALSE,
    progress = FALSE
  ) %>%
    transmute(
      table = "genome_summary.tsv",
      genome = genome_id,
      Clade1 = clade_1,
      Clade2 = clade_2,
      Subclade = subclade,
      Subgroup = subgroup,
      Order,
      Family,
      Genus,
      Species
    )
}

tables <- bind_rows(
  read_taxonomy(master_path, "subclade_master.tsv"),
  read_taxonomy(cat_path, "subclade_cat.tsv"),
  read_taxonomy(table_path, "subclade.txt"),
  read_taxonomy(
    tree_annotation_path,
    "tree_annottable_ogpage_542.tsv"
  ),
  read_overview_taxonomy(overview_summary_path)
)

table_summary <- tables %>%
  group_by(table) %>%
  summarise(
    rows = n(),
    unique_genomes = n_distinct(genome),
    sar11_genomes = sum(Clade1 != "outgroup"),
    outgroups = sum(Clade1 == "outgroup"),
    missing_family_clades_I_to_III = sum(
      Clade1 %in% c("I", "II", "III") & is.na(Family)
    ),
    .groups = "drop"
  )

stopifnot(
  all(table_summary$rows == if_else(
    table_summary$table == "genome_summary.tsv",
    542L,
    562L
  )),
  all(table_summary$unique_genomes == table_summary$rows),
  all(table_summary$sar11_genomes == 542L),
  all(table_summary$outgroups == if_else(
    table_summary$table == "genome_summary.tsv",
    0L,
    20L
  ))
)

consistency <- tables %>%
  pivot_longer(
    cols = all_of(setdiff(taxonomy_columns, "genome")),
    names_to = "field",
    values_to = "value"
  ) %>%
  group_by(genome, field) %>%
  summarise(
    distinct_values = n_distinct(value, na.rm = FALSE),
    values = paste(
      unique(if_else(is.na(value), "NA", value)),
      collapse = " | "
    ),
    .groups = "drop"
  ) %>%
  filter(distinct_values > 1L)

stopifnot(nrow(consistency) == 0L)

internal_audit <- read_tsv(
  audit_path,
  show_col_types = FALSE,
  na = "NA"
)
validation <- read_tsv(
  validation_path,
  show_col_types = FALSE,
  na = "NA"
)

topology_support_columns <- grep(
  "_SAR11_165_crown_support$",
  names(internal_audit),
  value = TRUE
)
stopifnot(
  length(topology_support_columns) == 3L,
  !any(grepl("bac120|dual_tree", names(internal_audit))),
  !any(
    internal_audit$Family_assignment_confidence == "topology_provisional",
    na.rm = TRUE
  ),
  !any(
    internal_audit$Genus_assignment_confidence == "topology_provisional",
    na.rm = TRUE
  ),
  !any(
    internal_audit$Subclade_assignment_confidence == "topology_provisional",
    na.rm = TRUE
  ),
  all(vapply(
    topology_support_columns,
    function(column_name) {
      all(internal_audit[[column_name]] >= 0.95, na.rm = TRUE)
    },
    logical(1)
  )),
  !any(grepl(
    "bac120|dual.tree|provisional|monophyletic_UFBoot95_clade",
    unlist(internal_audit[grep("_assignment_source$", names(internal_audit))]),
    ignore.case = TRUE
  ), na.rm = TRUE)
)

for (rank_name in c("Family", "Genus", "Subclade")) {
  source_column <- paste0(rank_name, "_assignment_source")
  confidence_column <- paste0(rank_name, "_assignment_confidence")
  support_column <- paste0(rank_name, "_SAR11_165_crown_support")
  topology_rows <- internal_audit[[confidence_column]] == "topology_high"
  topology_rows[is.na(topology_rows)] <- FALSE
  stopifnot(
    all(!is.na(internal_audit[[support_column]][topology_rows])),
    all(internal_audit[[support_column]][topology_rows] >= 0.95)
  )
}

stopifnot(!any(grepl(
  "crown interpolation",
  internal_audit$Species_assignment_source
), na.rm = TRUE))

ani_assignments <- read_tsv(
  file.path(output_dir, "ANI95_AAI95_species_assignments.tsv"),
  show_col_types = FALSE,
  na = "NA"
)
stopifnot(
  all(ani_assignments$ANI_to_species_reference >= 95),
  all(ani_assignments$AAI_to_species_reference >= 95),
  !anyDuplicated(ani_assignments$genome)
)

validation_reasons <- validation %>%
  mutate(
    audited_rank = case_when(
      rank %in% c("Family", "Family_prior_validation") ~ "Family",
      rank %in% c(
        "Genus_Subclade",
        "Genus_Subclade_prior_validation"
      ) ~ "Subclade",
      TRUE ~ rank
    )
  ) %>%
  group_by(audited_rank, taxon) %>%
  summarise(
    validation_reasons = paste(
      sort(unique(na.omit(exclusion_reason))),
      collapse = ";"
    ),
    eligible_in_any_tree = any(eligible_crown),
    .groups = "drop"
  )

rank_gaps <- bind_rows(
  lapply(c("Family", "Genus", "Subclade", "Species"), function(rank_name) {
    original_name <- paste0("original_", rank_name)
    internal_audit %>%
      filter(
        Clade1 != "outgroup",
        is.na(.data[[rank_name]])
      ) %>%
      transmute(
        genome,
        Clade1,
        type,
        rank = rank_name,
        prior_value = .data[[original_name]],
        Family,
        Genus,
        Subclade,
        Species
      )
  })
) %>%
  left_join(
    validation_reasons,
    by = c("rank" = "audited_rank", "prior_value" = "taxon")
  ) %>%
  mutate(
    gap_category = case_when(
      rank == "Family" & Clade1 == "IV" ~
        "outside_harmonization_scope",
      is.na(prior_value) ~
        "no_prior_label_and_no_supported_assignment",
      rank == "Species" ~
        "prior_species_not_supported_by_direct_or_ANI_evidence",
      validation_reasons == "insufficient_seeds" ~
        "insufficient_independent_seeds",
      !is.na(validation_reasons) ~
        "prior_label_failed_SAR11_165_high_support_criteria",
      TRUE ~
        "prior_label_not_recognized_in_current_taxonomy_framework"
    ),
    validation_reasons = na_if(validation_reasons, "")
  ) %>%
  arrange(rank, Clade1, genome)

write_tsv(
  table_summary,
  file.path(output_dir, "taxonomy_table_summary.tsv"),
  na = "NA"
)
write_tsv(
  consistency,
  file.path(output_dir, "taxonomy_table_inconsistencies.tsv"),
  na = "NA"
)
write_tsv(
  rank_gaps,
  file.path(output_dir, "taxonomy_assignment_gap_audit.tsv"),
  na = "NA"
)

message("Taxonomy output audit passed.")
print(table_summary)
print(rank_gaps %>% count(rank, gap_category))
