suppressPackageStartupMessages({
  library(ape)
  library(dplyr)
  library(readr)
  library(stringr)
})

phylogeny_dir <- "data/phylogeny"
tree_dir <- file.path(phylogeny_dir, "tree")
figure_dir <- file.path(
  phylogeny_dir,
  "taxonomy_harmonization",
  "figures",
  "iqtree_tree_comparison"
)
dir.create(figure_dir, recursive = TRUE, showWarnings = FALSE)

metadata <- read_tsv(
  file.path(phylogeny_dir, "subclade_master.tsv"),
  show_col_types = FALSE,
  na = "NA"
)
outgroup_tips <- metadata$genome[metadata$Clade1 == "outgroup"]
sar11_tips <- metadata$genome[metadata$Clade1 != "outgroup"]

metadata <- metadata %>%
  mutate(
    family_group = case_when(
      !is.na(Family) ~ Family,
      Clade1 == "IV" ~ "Family-unassigned Clade IV",
      TRUE ~ "Unassigned"
    )
  )
tip_groups <- setNames(metadata$family_group, metadata$genome)

family_colors <- c(
  "Pelagibacteraceae" = "#2378B5",
  "Cosmipelagibacteraceae" = "#E59624",
  "Mesopelagibacteraceae" = "#C65D93",
  "Fontibacteriaceae" = "#3FA168",
  "Family-unassigned Clade IV" = "#68737D",
  "Unassigned" = "#B8BEC4"
)

tree_paths <- c(
  "A  bac120 markers" = file.path(
    tree_dir,
    "SAR11_542_bac120_iqtree.tree"
  ),
  "B  SAR11_165 markers" = file.path(
    tree_dir,
    "SAR11_542_SCG165_iqtree.tree"
  )
)

prepare_tree <- function(path) {
  tree <- read.tree(path)
  stopifnot(
    Ntip(tree) == 562L,
    setequal(tree$tip.label, c(sar11_tips, outgroup_tips)),
    is.monophyletic(tree, outgroup_tips, reroot = TRUE)
  )
  tree <- root(tree, outgroup = outgroup_tips, resolve.root = TRUE)
  tree <- keep.tip(tree, sar11_tips)
  ladderize(tree)
}

get_edge_colors <- function(tree) {
  total_nodes <- Ntip(tree) + tree$Nnode
  node_group <- rep("Mixed", total_nodes)
  node_group[seq_len(Ntip(tree))] <- tip_groups[tree$tip.label]

  internal_nodes <- rev(seq.int(Ntip(tree) + 1L, total_nodes))
  for (node in internal_nodes) {
    children <- tree$edge[tree$edge[, 1] == node, 2]
    child_groups <- unique(node_group[children])
    if (length(child_groups) == 1L && child_groups != "Mixed") {
      node_group[node] <- child_groups
    }
  }

  child_groups <- node_group[tree$edge[, 2]]
  ifelse(
    child_groups %in% names(family_colors),
    family_colors[child_groups],
    "#53606A"
  )
}

extract_ufboot <- function(labels) {
  suppressWarnings(as.numeric(str_extract(labels, "[0-9.]+$")))
}

plot_tree_panel <- function(tree, panel_title) {
  plot.phylo(
    tree,
    type = "phylogram",
    direction = "rightwards",
    use.edge.length = TRUE,
    show.tip.label = FALSE,
    edge.color = get_edge_colors(tree),
    edge.width = 0.45,
    no.margin = FALSE,
    label.offset = 0
  )
  tiplabels(
    pch = 15,
    col = family_colors[tip_groups[tree$tip.label]],
    cex = 0.28
  )
  ufboot <- extract_ufboot(tree$node.label)
  supported_nodes <- which(ufboot >= 95) + Ntip(tree)
  nodelabels(
    node = supported_nodes,
    pch = 16,
    col = "black",
    cex = 0.22
  )
  add.scale.bar(
    length = 0.05,
    lwd = 1.2,
    cex = 0.75
  )
  title(
    main = panel_title,
    adj = 0,
    cex.main = 1.05,
    font.main = 2
  )
}

trees <- lapply(tree_paths, prepare_tree)

draw_figure <- function() {
  layout(
    matrix(c(1, 2, 3, 3), nrow = 2, byrow = TRUE),
    heights = c(12, 1)
  )
  par(
    mar = c(2.5, 1.2, 3.5, 1.2),
    oma = c(0.5, 0.5, 4.2, 0.5),
    xaxs = "i"
  )
  Map(plot_tree_panel, trees, names(trees))
  mtext(
    "Family-level organization across the two IQ-TREE 2 phylogenies",
    side = 3,
    outer = TRUE,
    line = 1.8,
    cex = 1.35,
    font = 2
  )
  mtext(
    "Colored branches: family-level lineage; black circles: UFBoot >=95; scale bars: 0.05 expected amino-acid substitutions per aligned site",
    side = 3,
    outer = TRUE,
    line = 0.3,
    cex = 0.78,
    col = "#53606A"
  )
  par(mar = c(0, 0, 0, 0))
  plot.new()
  legend(
    "center",
    legend = names(family_colors),
    col = family_colors,
    lwd = 4,
    bty = "n",
    horiz = TRUE,
    cex = 0.76
  )
}

png(
  file.path(figure_dir, "supp_iqtree_family_comparison.png"),
  width = 3600,
  height = 2200,
  res = 240,
  bg = "white"
)
draw_figure()
dev.off()

pdf(
  file.path(figure_dir, "supp_iqtree_family_comparison.pdf"),
  width = 15,
  height = 9.2,
  useDingbats = FALSE
)
draw_figure()
dev.off()

relationship_summary <- read_tsv(
  file.path(
    phylogeny_dir,
    "taxonomy_harmonization",
    "outputs",
    "final_dual_iqtree",
    "dual_iqtree_family_relationship.tsv"
  ),
  show_col_types = FALSE
) %>%
  transmute(
    marker_set = recode(
      marker_tree,
      "bac120 IQ-TREE 2" = "bac120 markers",
      "SAR11_165 IQ-TREE 2" = "SAR11_165 markers"
    ),
    mesopelagibacteraceae_genomes,
    sister_lineage = if_else(
      sister_lineages,
      "Cosmipelagibacteraceae",
      "Not uniquely resolved"
    ),
    ufboot_support = ufboot
  )

write_tsv(
  relationship_summary,
  file.path(figure_dir, "iqtree_family_comparison_summary.tsv")
)

message("Final IQ-TREE 2 family comparison figure written to: ", figure_dir)
