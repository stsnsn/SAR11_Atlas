suppressPackageStartupMessages({
  library(ape)
  library(dplyr)
  library(readr)
  library(stringr)
})

phylogeny_dir <- "data/phylogeny"
tree_dir <- file.path(phylogeny_dir, "tree")
harmonization_dir <- file.path(
  phylogeny_dir,
  "taxonomy_harmonization"
)
script_dir <- file.path("data", "phylogeny", "scripts")
output_dir <- file.path(
  harmonization_dir,
  "outputs",
  "final_dual_iqtree"
)

metadata_path <- file.path(phylogeny_dir, "subclade_master.tsv")
bac120_tree_path <- file.path(
  tree_dir,
  "SAR11_542_bac120_iqtree.tree"
)
scg165_tree_path <- file.path(
  tree_dir,
  "SAR11_542_SCG165_iqtree.tree"
)
scg165_rooted_sar11_path <- file.path(
  tree_dir,
  "SAR11_542_SCG165_iqtree_rooted_SAR11_only.tree"
)

required_paths <- c(
  metadata_path,
  bac120_tree_path,
  scg165_tree_path,
  file.path(script_dir, "build_harmonized_taxonomy.R"),
  file.path(script_dir, "promote_harmonized_taxonomy.R"),
  file.path(script_dir, "audit_taxonomy_outputs.R"),
  file.path(script_dir, "validate_final_phylogeny.R")
)
stopifnot(all(file.exists(required_paths)))

metadata <- read_tsv(
  metadata_path,
  show_col_types = FALSE,
  na = "NA"
)
outgroup_tips <- metadata %>%
  filter(Clade1 == "outgroup") %>%
  pull(genome)
sar11_tips <- metadata %>%
  filter(Clade1 != "outgroup") %>%
  pull(genome)

validate_full_tree <- function(tree, label) {
  stopifnot(
    Ntip(tree) == 562L,
    length(outgroup_tips) == 20L,
    length(sar11_tips) == 542L,
    !anyDuplicated(tree$tip.label),
    setequal(
      tree$tip.label,
      c(sar11_tips, outgroup_tips)
    ),
    is.monophyletic(
      tree,
      outgroup_tips,
      reroot = TRUE
    )
  )

  ufboot <- suppressWarnings(
    as.numeric(str_extract(tree$node.label, "[0-9.]+$"))
  )
  stopifnot(
    sum(!is.na(ufboot)) >= tree$Nnode - 10L,
    all(ufboot[!is.na(ufboot)] >= 0),
    all(ufboot[!is.na(ufboot)] <= 100)
  )
  message(
    label,
    ": 562 tips; ",
    sum(!is.na(ufboot)),
    " supported internal labels; ",
    sum(ufboot >= 95, na.rm = TRUE),
    " nodes with UFBoot >=95."
  )
}

bac120_tree <- read.tree(bac120_tree_path)
scg165_tree <- read.tree(scg165_tree_path)
validate_full_tree(bac120_tree, "bac120 IQ-TREE 2")
validate_full_tree(scg165_tree, "SAR11_165 IQ-TREE 2")

scg165_rooted <- root(
  scg165_tree,
  outgroup = outgroup_tips,
  resolve.root = TRUE
)
scg165_sar11 <- keep.tip(
  scg165_rooted,
  sar11_tips
)
stopifnot(
  is.rooted(scg165_rooted),
  is.rooted(scg165_sar11),
  Ntip(scg165_sar11) == 542L,
  !anyDuplicated(scg165_sar11$tip.label),
  setequal(scg165_sar11$tip.label, sar11_tips),
  !any(scg165_sar11$tip.label %in% outgroup_tips)
)
write.tree(
  scg165_sar11,
  file = scg165_rooted_sar11_path
)

previous_promoted <- metadata %>%
  select(
    genome,
    previous_Subclade = Subclade,
    previous_Family = Family,
    previous_Genus = Genus,
    previous_Species = Species
  )

dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
Sys.setenv(
  HARMONIZED_OUTPUT_DIR = output_dir,
  HARMONIZED_BAC120_TREE = bac120_tree_path,
  HARMONIZED_SCG165_TREE = scg165_tree_path,
  HARMONIZED_TOPOLOGY_LOW_SUPPORT = "0.50",
  HARMONIZED_TOPOLOGY_HIGH_SUPPORT = "0.95",
  HARMONIZED_PRESERVE_FREEL_IIA = "true",
  HARMONIZED_PRESERVE_CLADE_III = "true",
  HARMONIZED_BAC120_LABEL = "bac120 IQ-TREE 2 (UFBoot)",
  HARMONIZED_SCG165_LABEL = "SAR11_165 IQ-TREE 2 (UFBoot)",
  HARMONIZED_VALIDATION_FILENAME =
    "dual_iqtree_taxon_validation.tsv"
)

source(file.path(script_dir, "build_harmonized_taxonomy.R"))

final_candidate <- output %>%
  select(
    genome,
    final_Subclade = Subclade,
    final_Family = Family,
    final_Genus = Genus,
    final_Species = Species,
    Subclade_assignment_source,
    Family_assignment_source,
    Genus_assignment_source,
    Species_assignment_source
  )
changes_vs_previous <- previous_promoted %>%
  left_join(final_candidate, by = "genome") %>%
  mutate(
    subclade_changed = coalesce(
      previous_Subclade != final_Subclade,
      xor(is.na(previous_Subclade), is.na(final_Subclade))
    ),
    family_changed = coalesce(
      previous_Family != final_Family,
      xor(is.na(previous_Family), is.na(final_Family))
    ),
    genus_changed = coalesce(
      previous_Genus != final_Genus,
      xor(is.na(previous_Genus), is.na(final_Genus))
    ),
    species_changed = coalesce(
      previous_Species != final_Species,
      xor(is.na(previous_Species), is.na(final_Species))
    )
  ) %>%
  filter(
    subclade_changed |
      family_changed |
      genus_changed |
      species_changed
  )
write_tsv(
  changes_vs_previous,
  file.path(output_dir, "changes_vs_previous_promoted.tsv"),
  na = "NA"
)

Sys.setenv(
  HARMONIZED_CANDIDATE_PATH = file.path(
    output_dir,
    "subclade_harmonized.tsv"
  )
)
source(file.path(script_dir, "promote_harmonized_taxonomy.R"))
source(file.path(script_dir, "audit_taxonomy_outputs.R"))
source(file.path(script_dir, "validate_final_phylogeny.R"))

message(
  "Final rooted SAR11_165 tree: ",
  scg165_rooted_sar11_path
)
message(
  "Final dual-IQ-TREE taxonomy: ",
  file.path(output_dir, "subclade_harmonized.tsv")
)
message(
  "Taxonomy changes versus the previously promoted table: ",
  nrow(changes_vs_previous)
)
