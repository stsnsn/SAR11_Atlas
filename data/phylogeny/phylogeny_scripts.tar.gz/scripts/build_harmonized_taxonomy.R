suppressPackageStartupMessages({
  library(ape)
  library(dplyr)
  library(readr)
  library(stringr)
  library(tidyr)
})

input_dir <- "data/phylogeny"
harmonization_dir <- file.path(input_dir, "taxonomy_harmonization")
freel_input_dir <- file.path(harmonization_dir, "inputs", "freel")
freshwater_input_dir <- file.path(
  harmonization_dir,
  "inputs",
  "freshwater"
)
output_dir <- Sys.getenv(
  "HARMONIZED_OUTPUT_DIR",
  unset = file.path(
    harmonization_dir,
    "outputs",
    "final_sar11_165_iqtree_high_support"
  )
)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

meta_path <- Sys.getenv(
  "HARMONIZED_BASELINE_METADATA",
  unset = file.path(
    harmonization_dir,
    "outputs",
    "final_sar11_165_iqtree_high_support",
    "subclade_harmonized.tsv"
  )
)
prior_freel_path <- Sys.getenv(
  "HARMONIZED_PRIOR_FREEL_METADATA",
  unset = file.path(
    harmonization_dir,
    "inputs",
    "freel",
    "subclade_harmonized_freel_baseline.tsv"
  )
)
freel_species_path <- file.path(
  freel_input_dir,
  "freel_species_direct_evidence.tsv"
)
freel_types_path <- file.path(
  freel_input_dir,
  "freel_species_type_references.tsv"
)
ani_path <- file.path(
  input_dir,
  "fastani_SAR11_542_symmetric_matrix.tsv"
)
aai_path <- file.path(
  input_dir,
  "comparem_aaiwf_SAR11_542_out_summary.tsv"
)
lanclos_path <- file.path(
  freshwater_input_dir,
  "lanclos_2023_atlas_matches.tsv"
)
fernandes_path <- file.path(
  freshwater_input_dir,
  "fernandes_2025_atlas_matches.tsv"
)
scg165_tree_path <- Sys.getenv(
  "HARMONIZED_SCG165_TREE",
  unset = file.path(
    input_dir,
    "tree",
    "SAR11_542_SCG165_iqtree.tree"
  )
)
topology_high_support <- as.numeric(
  Sys.getenv("HARMONIZED_TOPOLOGY_HIGH_SUPPORT", unset = "0.95")
)
# Topology-derived assignments are accepted only at high support.
topology_low_support <- topology_high_support
preserve_freel_iia <- identical(
  tolower(Sys.getenv("HARMONIZED_PRESERVE_FREEL_IIA", unset = "false")),
  "true"
)
preserve_clade_iii <- identical(
  tolower(Sys.getenv("HARMONIZED_PRESERVE_CLADE_III", unset = "false")),
  "true"
)
scg165_tree_label <- Sys.getenv(
  "HARMONIZED_SCG165_LABEL",
  unset = "SAR11_165 IQ-TREE 2 (UFBoot)"
)
# Compatibility alias for the original dual-branch inference helpers.
validation_filename <- Sys.getenv(
  "HARMONIZED_VALIDATION_FILENAME",
  unset = "sar11_165_taxon_validation.tsv"
)

source_labels <- c(
  freel_type = "Freel et al. 2025 Type Strains",
  freel_used = "Freel et al. 2025 used genome",
  freel_iia = "Freel et al. 2025 IIa.A/IIa.B classification",
  fernandes = "Fernandes et al. 2025 genomes",
  lanclos = "Lanclos et al. 2023 used genome",
  lanclos_freel =
    "Lanclos et al. 2023 subgroup + Freel et al. 2025 taxonomy",
  curated_iii =
    "Curated Clade III classification in Lanclos/Fernandes framework",
  curated_freel_iii =
    "Curated Clade III subgroup + Freel et al. 2025 taxonomy",
  topology_high =
    "SAR11_165 crown interpolation (high confidence)",
  topology_provisional =
    "SAR11_165 crown interpolation (provisional)",
  prior_family_high =
    "SAR11_165 validation of prior family assignment (high confidence)",
  prior_family_provisional =
    "SAR11_165 validation of prior family assignment (provisional)",
  prior_lineage_high =
    "SAR11_165 validation of prior lineage assignment (high confidence)",
  prior_lineage_provisional =
    "SAR11_165 validation of prior lineage assignment (provisional)",
  legacy = "Retained legacy classification outside harmonization scope",
  outgroup = "Retained outgroup classification"
)

rank_names <- c("Subclade", "Family", "Genus", "Species")
source_names <- paste0(rank_names, "_assignment_source")
confidence_names <- paste0(rank_names, "_assignment_confidence")

parse_node_support <- function(label) {
  value <- suppressWarnings(
    as.numeric(str_extract(label, "[0-9.]+$"))
  )
  ifelse(value > 1, value / 100, value)
}

descendant_tips <- function(tree, node) {
  if (length(node) == 0 || is.na(node)) {
    return(character())
  }
  if (node <= Ntip(tree)) {
    return(tree$tip.label[[node]])
  }
  extract.clade(tree, node)$tip.label
}

node_support <- function(tree, node) {
  if (length(node) == 0 || is.na(node) || node <= Ntip(tree)) {
    return(NA_real_)
  }
  parse_node_support(tree$node.label[[node - Ntip(tree)]])
}

prepare_tree <- function(path, sar11_tips, outgroup_tips) {
  tree <- read.tree(path)
  stopifnot(
    !anyDuplicated(tree$tip.label),
    setequal(tree$tip.label, c(sar11_tips, outgroup_tips)),
    is.monophyletic(tree, outgroup_tips, reroot = TRUE)
  )
  rooted <- root(
    tree,
    outgroup = outgroup_tips,
    resolve.root = TRUE
  )
  keep.tip(rooted, sar11_tips)
}

apply_assignments <- function(target, assignments) {
  if (nrow(assignments) == 0) {
    return(target)
  }
  stopifnot(!anyDuplicated(assignments$genome))
  index <- match(target$genome, assignments$genome)

  for (rank_name in rank_names) {
    source_name <- paste0(rank_name, "_assignment_source")
    new_value <- assignments[[rank_name]][index]
    new_source <- assignments[[source_name]][index]
    fill <- is.na(target[[rank_name]]) & !is.na(new_value)
    target[[rank_name]][fill] <- new_value[fill]
    target[[source_name]][fill] <- new_source[fill]
  }
  target
}

seed_class_from_source <- function(source) {
  case_when(
    is.na(source) ~ NA_character_,
    str_detect(source, "^ANI>=95% and AAI>=95%") ~
      "supplementary_ANI95_AAI95",
    source %in% c(
      source_labels[["legacy"]],
      source_labels[["outgroup"]],
      source_labels[["curated_iii"]],
      source_labels[["curated_freel_iii"]],
      source_labels[["topology_high"]],
      source_labels[["topology_provisional"]],
      source_labels[["prior_family_high"]],
      source_labels[["prior_family_provisional"]],
      source_labels[["prior_lineage_high"]],
      source_labels[["prior_lineage_provisional"]]
    ) ~ NA_character_,
    TRUE ~ "primary_direct"
  )
}

screen_seed_bounded_crowns <- function(
    tree,
    seed_table,
    rank_name,
    tree_name,
    minimum_support = topology_low_support
) {
  internal_nodes <- seq.int(
    Ntip(tree) + 1L,
    Ntip(tree) + tree$Nnode
  )
  validation_rows <- list()
  membership_rows <- list()

  for (taxon_name in sort(unique(seed_table$taxon))) {
    target_seeds <- seed_table %>%
      filter(taxon == taxon_name)
    target_tips <- target_seeds$genome
    primary_tips <- target_seeds %>%
      filter(seed_class == "primary_direct") %>%
      pull(genome)

    if (length(target_tips) < 2L || length(primary_tips) < 1L) {
      validation_rows[[paste0(taxon_name, "_insufficient")]] <- tibble(
        tree = tree_name,
        rank = rank_name,
        taxon = taxon_name,
        node = NA_integer_,
        support = NA_real_,
        descendant_genomes = length(target_tips),
        target_seeds = length(target_tips),
        primary_seeds = length(primary_tips),
        foreign_seeds = NA_integer_,
        seed_defined_mrca = FALSE,
        parent_taxon = NA_character_,
        parent_consistent = FALSE,
        eligible_crown = FALSE,
        exclusion_reason = "insufficient_seeds"
      )
      next
    }

    parent_values <- target_seeds$parent_taxon %>%
      na.omit() %>%
      unique()
    parent_consistent <- length(parent_values) <= 1L
    parent_taxon <- if (length(parent_values) == 1L) {
      parent_values[[1]]
    } else {
      NA_character_
    }
    overall_mrca <- getMRCA(tree, target_tips)
    overall_descendants <- descendant_tips(tree, overall_mrca)

    for (node in internal_nodes) {
      descendants <- descendant_tips(tree, node)
      if (!all(descendants %in% overall_descendants)) {
        next
      }

      node_target_tips <- intersect(descendants, target_tips)
      if (length(node_target_tips) < 2L) {
        next
      }

      node_primary_tips <- intersect(descendants, primary_tips)
      node_foreign_seeds <- seed_table %>%
        filter(
          genome %in% descendants,
          taxon != taxon_name
        )
      support <- node_support(tree, node)
      seed_mrca <- getMRCA(tree, node_target_tips)
      seed_defined_mrca <- identical(
        as.integer(seed_mrca),
        as.integer(node)
      )
      eligible <- length(node_primary_tips) >= 1L &&
        nrow(node_foreign_seeds) == 0L &&
        parent_consistent &&
        seed_defined_mrca &&
        !is.na(support) &&
        support >= minimum_support
      exclusion_reason <- case_when(
        length(node_primary_tips) < 1L ~ "no_primary_seed",
        nrow(node_foreign_seeds) > 0L ~ "competing_seed",
        !parent_consistent ~ "inconsistent_parent",
        !seed_defined_mrca ~ "candidate_expands_seed_crown",
        is.na(support) ~ "missing_support",
        support < minimum_support ~ "support_below_threshold",
        TRUE ~ NA_character_
      )

      row_key <- paste(taxon_name, tree_name, node, sep = "_")
      validation_rows[[row_key]] <- tibble(
        tree = tree_name,
        rank = rank_name,
        taxon = taxon_name,
        node = node,
        support = support,
        descendant_genomes = length(descendants),
        target_seeds = length(node_target_tips),
        primary_seeds = length(node_primary_tips),
        foreign_seeds = nrow(node_foreign_seeds),
        seed_defined_mrca = seed_defined_mrca,
        parent_taxon = parent_taxon,
        parent_consistent = parent_consistent,
        eligible_crown = eligible,
        exclusion_reason = exclusion_reason
      )

      if (eligible) {
        membership_rows[[row_key]] <- tibble(
          genome = descendants,
          taxon = taxon_name,
          parent_taxon = parent_taxon,
          tree = tree_name,
          node = node,
          support = support,
          descendant_genomes = length(descendants),
          target_seeds = length(node_target_tips),
          primary_seeds = length(node_primary_tips)
        )
      }
    }
  }

  validation <- bind_rows(validation_rows)
  memberships <- bind_rows(membership_rows)

  if (nrow(memberships) > 0L) {
    memberships <- memberships %>%
      group_by(genome, taxon) %>%
      arrange(
        descendant_genomes,
        desc(support),
        desc(target_seeds),
        .by_group = TRUE
      ) %>%
      slice_head(n = 1L) %>%
      ungroup()

    ambiguous <- memberships %>%
      distinct(genome, taxon) %>%
      count(genome, name = "candidate_taxa") %>%
      filter(candidate_taxa > 1L)

    memberships <- memberships %>%
      anti_join(ambiguous, by = "genome")
  }

  list(
    validation = validation,
    memberships = memberships
  )
}

infer_single_tree_assignments <- function(
    taxonomy,
    seed_table,
    rank_name,
    tree_scg165
) {
  scg165_result <- screen_seed_bounded_crowns(
    tree_scg165,
    seed_table,
    rank_name,
    "SAR11_165",
    topology_low_support
  )

  scg165_memberships <- scg165_result$memberships %>%
    rename(
      scg165_taxon = taxon,
      scg165_parent_taxon = parent_taxon,
      scg165_node = node,
      scg165_support = support,
      scg165_descendants = descendant_genomes,
      scg165_target_seeds = target_seeds,
      scg165_primary_seeds = primary_seeds
    ) %>%
    select(-tree)

  decisions <- scg165_memberships %>%
    mutate(
      rank = rank_name,
      assignment_confidence = if_else(
        scg165_support >= topology_high_support,
        "topology_high",
        NA_character_
      ),
      decision = if_else(
        !is.na(assignment_confidence),
        "topology_high",
        "no_eligible_SAR11_165_crown"
      )
    )

  assignments <- decisions %>%
    filter(!is.na(assignment_confidence)) %>%
    transmute(
      genome,
      taxon = scg165_taxon,
      parent_taxon = scg165_parent_taxon,
      assignment_confidence,
      assignment_source = if_else(
        assignment_confidence == "topology_high",
        source_labels[["topology_high"]],
        source_labels[["topology_provisional"]]
      ),
      scg165_node,
      scg165_support,
      scg165_descendants
    )

  list(
    assignments = assignments,
    decisions = decisions,
    validation = scg165_result$validation
  )
}

validate_prior_single_seed_families <- function(
    taxonomy,
    original_metadata,
    seed_table,
    tree_scg165
) {
  singleton_families <- seed_table %>%
    group_by(taxon) %>%
    summarise(
      target_seeds = n_distinct(genome),
      primary_seeds = n_distinct(
        genome[seed_class == "primary_direct"]
      ),
      .groups = "drop"
    ) %>%
    filter(
      target_seeds == 1L,
      primary_seeds == 1L
    ) %>%
    pull(taxon)

  validation_rows <- list()
  assignment_rows <- list()

  evaluate_tree <- function(tree, candidate_tips, taxon_name, tree_name) {
    node <- getMRCA(tree, candidate_tips)
    descendants <- descendant_tips(tree, node)
    support <- node_support(tree, node)
    foreign_seeds <- seed_table %>%
      filter(
        genome %in% descendants,
        taxon != taxon_name
      ) %>%
      nrow()
    exact_prior_crown <- setequal(descendants, candidate_tips)
    eligible <- exact_prior_crown &&
      foreign_seeds == 0L &&
      !is.na(support) &&
      support >= topology_low_support
    exclusion_reason <- case_when(
      !exact_prior_crown ~ "prior_group_not_exact_crown",
      foreign_seeds > 0L ~ "competing_seed",
      is.na(support) ~ "missing_support",
      support < topology_low_support ~ "support_below_threshold",
      TRUE ~ NA_character_
    )

    list(
      node = node,
      support = support,
      descendants = descendants,
      foreign_seeds = foreign_seeds,
      exact_prior_crown = exact_prior_crown,
      eligible = eligible,
      exclusion_reason = exclusion_reason,
      validation = tibble(
        tree = tree_name,
        rank = "Family_prior_validation",
        taxon = taxon_name,
        node = node,
        support = support,
        descendant_genomes = length(descendants),
        target_seeds = 1L,
        primary_seeds = 1L,
        foreign_seeds = foreign_seeds,
        seed_defined_mrca = exact_prior_crown,
        parent_taxon = NA_character_,
        parent_consistent = TRUE,
        eligible_crown = eligible,
        exclusion_reason = exclusion_reason
      )
    )
  }

  for (taxon_name in singleton_families) {
    candidate_tips <- original_metadata %>%
      filter(
        genome %in% taxonomy$genome,
        Family == taxon_name
      ) %>%
      pull(genome) %>%
      unique()

    if (length(candidate_tips) < 2L) {
      next
    }

    existing_conflict <- taxonomy %>%
      filter(
        genome %in% candidate_tips,
        !is.na(Family),
        Family != taxon_name
      ) %>%
      nrow()

    scg165 <- evaluate_tree(
      tree_scg165,
      candidate_tips,
      taxon_name,
      "SAR11_165"
    )
    validation_rows[[paste0(taxon_name, "_SAR11_165")]] <-
      scg165$validation

    assignment_confidence <- case_when(
      existing_conflict > 0L ~ NA_character_,
      scg165$eligible &&
        scg165$support >= topology_high_support ~
        "topology_high",
      TRUE ~ NA_character_
    )

    if (is.na(assignment_confidence)) {
      next
    }

    assignment_source <- if (
      assignment_confidence == "topology_high"
    ) {
      source_labels[["prior_family_high"]]
    } else {
      source_labels[["prior_family_provisional"]]
    }

    assignment_rows[[taxon_name]] <- tibble(
      genome = candidate_tips,
      taxon = taxon_name,
      parent_taxon = NA_character_,
      assignment_confidence = assignment_confidence,
      assignment_source = assignment_source,
      scg165_node = scg165$node,
      scg165_support = scg165$support,
      scg165_descendants = length(scg165$descendants)
    )
  }

  list(
    assignments = bind_rows(assignment_rows),
    validation = bind_rows(validation_rows)
  )
}

validate_prior_single_seed_lineages <- function(
    taxonomy,
    original_metadata,
    seed_table,
    tree_scg165
) {
  singleton_lineages <- seed_table %>%
    group_by(taxon) %>%
    summarise(
      target_seeds = n_distinct(genome),
      primary_seeds = n_distinct(
        genome[seed_class == "primary_direct"]
      ),
      .groups = "drop"
    ) %>%
    filter(
      target_seeds == 1L,
      primary_seeds == 1L
    )

  validation_rows <- list()
  assignment_rows <- list()

  evaluate_tree <- function(tree, candidate_tips, taxon_name, tree_name) {
    node <- getMRCA(tree, candidate_tips)
    descendants <- descendant_tips(tree, node)
    support <- node_support(tree, node)
    foreign_seeds <- seed_table %>%
      filter(
        genome %in% descendants,
        taxon != taxon_name
      ) %>%
      nrow()
    exact_prior_crown <- setequal(descendants, candidate_tips)
    eligible <- exact_prior_crown &&
      foreign_seeds == 0L &&
      !is.na(support) &&
      support >= topology_low_support
    exclusion_reason <- case_when(
      !exact_prior_crown ~ "prior_group_not_exact_crown",
      foreign_seeds > 0L ~ "competing_seed",
      is.na(support) ~ "missing_support",
      support < topology_low_support ~ "support_below_threshold",
      TRUE ~ NA_character_
    )

    list(
      node = node,
      support = support,
      descendants = descendants,
      eligible = eligible,
      validation = tibble(
        tree = tree_name,
        rank = "Genus_Subclade_prior_validation",
        taxon = taxon_name,
        node = node,
        support = support,
        descendant_genomes = length(descendants),
        target_seeds = 1L,
        primary_seeds = 1L,
        foreign_seeds = foreign_seeds,
        seed_defined_mrca = exact_prior_crown,
        parent_taxon = NA_character_,
        parent_consistent = TRUE,
        eligible_crown = eligible,
        exclusion_reason = exclusion_reason
      )
    )
  }

  for (taxon_name in singleton_lineages$taxon) {
    target_seed <- seed_table %>%
      filter(
        taxon == taxon_name,
        seed_class == "primary_direct"
      ) %>%
      slice_head(n = 1L)
    prior_subclade <- original_metadata %>%
      filter(genome == target_seed$genome[[1]]) %>%
      pull(Subclade)

    if (length(prior_subclade) != 1L || is.na(prior_subclade)) {
      next
    }

    candidate_tips <- original_metadata %>%
      filter(
        genome %in% taxonomy$genome,
        Subclade == prior_subclade
      ) %>%
      pull(genome) %>%
      unique()

    if (length(candidate_tips) < 2L) {
      next
    }

    parent_taxon <- target_seed$parent_taxon[[1]]
    existing_conflict <- taxonomy %>%
      filter(
        genome %in% candidate_tips,
        (
          !is.na(Subclade) &
            Subclade != taxon_name
        ) |
          (
            !is.na(Family) &
              Family != parent_taxon
          )
      ) %>%
      nrow()

    scg165 <- evaluate_tree(
      tree_scg165,
      candidate_tips,
      taxon_name,
      "SAR11_165"
    )
    validation_rows[[paste0(taxon_name, "_SAR11_165")]] <-
      scg165$validation %>%
      mutate(parent_taxon = .env$parent_taxon)

    assignment_confidence <- case_when(
      existing_conflict > 0L ~ NA_character_,
      scg165$eligible &&
        scg165$support >= topology_high_support ~
        "topology_high",
      TRUE ~ NA_character_
    )

    if (is.na(assignment_confidence)) {
      next
    }

    assignment_source <- if (
      assignment_confidence == "topology_high"
    ) {
      source_labels[["prior_lineage_high"]]
    } else {
      source_labels[["prior_lineage_provisional"]]
    }

    assignment_rows[[taxon_name]] <- tibble(
      genome = candidate_tips,
      taxon = taxon_name,
      parent_taxon = parent_taxon,
      assignment_confidence = assignment_confidence,
      assignment_source = assignment_source,
      scg165_node = scg165$node,
      scg165_support = scg165$support,
      scg165_descendants = length(scg165$descendants)
    )
  }

  list(
    assignments = bind_rows(assignment_rows),
    validation = bind_rows(validation_rows)
  )
}

meta_original <- read_tsv(meta_path, show_col_types = FALSE)

# A promoted candidate retains the preceding classification in original_*.
# This makes the current audited output a self-contained regeneration baseline.
if (all(c(
  "original_Subclade",
  "original_Subgroup",
  "original_Family",
  "original_Genus",
  "original_Species"
) %in% names(meta_original))) {
  meta_original <- meta_original %>%
    mutate(
      Subclade = original_Subclade,
      Subgroup = original_Subgroup,
      Family = original_Family,
      Genus = original_Genus,
      Species = original_Species
    )
}

meta_original <- meta_original %>%
  select(
    -starts_with("original_"),
    -matches(
      "_assignment_(source|confidence)$|_(bac120|SAR11_165)_crown_(node|support)$|_dual_tree_support$"
    ),
    -any_of(c(
      "species_reference_genome",
      "ANI_to_species_reference",
      "AAI_to_species_reference"
    ))
  )
prior_freel <- read_tsv(prior_freel_path, show_col_types = FALSE)
freel_species <- read_tsv(freel_species_path, show_col_types = FALSE)
freel_types <- read_tsv(freel_types_path, show_col_types = FALSE)

# Freel's current nomenclature uses Anoxypelagibacter. Normalize historical
# spellings before constructing any direct, ANI/AAI, or topology seeds so the
# same genus is never split into two labels during inference.
normalize_freel_genus <- function(value) {
  if_else(
    value == "Anoxipelagibacter",
    "Anoxypelagibacter",
    value
  )
}
meta_original <- meta_original %>%
  mutate(across(any_of(c("Genus", "original_Genus")), normalize_freel_genus))
prior_freel <- prior_freel %>%
  mutate(across(any_of(c("Genus", "Genus_harmonized_freel", "original_Genus")), normalize_freel_genus))
freel_species <- freel_species %>%
  mutate(across(any_of(c("freel_genus", "Genus")), normalize_freel_genus))
freel_types <- freel_types %>%
  mutate(across(any_of(c("freel_genus", "Genus")), normalize_freel_genus))
ani_matrix <- read_tsv(ani_path, show_col_types = FALSE)
aai_pairs <- read_tsv(aai_path, show_col_types = FALSE)
lanclos_matches <- read_tsv(lanclos_path, show_col_types = FALSE)
fernandes_matches <- read_tsv(fernandes_path, show_col_types = FALSE)

sar11_tips <- meta_original %>%
  filter(Clade1 != "outgroup") %>%
  pull(genome)
outgroup_tips <- meta_original %>%
  filter(Clade1 == "outgroup") %>%
  pull(genome)

stopifnot(
  nrow(meta_original) == 562L,
  length(sar11_tips) == 542L,
  length(outgroup_tips) == 20L,
  !anyDuplicated(meta_original$genome),
  nrow(ani_matrix) == 542L,
  ncol(ani_matrix) == 543L,
  setequal(ani_matrix$genome, sar11_tips),
  setequal(names(ani_matrix)[-1], sar11_tips)
)

tree_scg165 <- prepare_tree(
  scg165_tree_path,
  sar11_tips,
  outgroup_tips
)

taxonomy <- meta_original %>%
  transmute(
    genome,
    Clade1,
    original_Subclade = Subclade,
    original_Subgroup = Subgroup,
    original_Family = Family,
    original_Genus = Genus,
    original_Species = Species,
    Subclade = NA_character_,
    Family = NA_character_,
    Genus = NA_character_,
    Species = NA_character_,
    Subclade_assignment_source = NA_character_,
    Family_assignment_source = NA_character_,
    Genus_assignment_source = NA_character_,
    Species_assignment_source = NA_character_,
    species_reference_genome = NA_character_,
    ANI_to_species_reference = NA_real_,
    AAI_to_species_reference = NA_real_
  )

# Clade IV was outside the requested harmonization scope. Its historical
# subclade label is retained, while lower ranks remain unassigned.
legacy_rows <- taxonomy %>%
  filter(Clade1 == "IV") %>%
  transmute(
    genome,
    Subclade = original_Subclade,
    Family = NA_character_,
    Genus = NA_character_,
    Species = NA_character_,
    Subclade_assignment_source = source_labels[["legacy"]],
    Family_assignment_source = NA_character_,
    Genus_assignment_source = NA_character_,
    Species_assignment_source = NA_character_
  )
taxonomy <- apply_assignments(taxonomy, legacy_rows)

outgroup_rows <- taxonomy %>%
  filter(Clade1 == "outgroup") %>%
  transmute(
    genome,
    Subclade = original_Subclade,
    Family = original_Family,
    Genus = original_Genus,
    Species = original_Species,
    Subclade_assignment_source = source_labels[["outgroup"]],
    Family_assignment_source = source_labels[["outgroup"]],
    Genus_assignment_source = source_labels[["outgroup"]],
    Species_assignment_source = source_labels[["outgroup"]]
  )
taxonomy <- apply_assignments(taxonomy, outgroup_rows)

# Freel retains the IIa.A/IIa.B distinction. When requested, preserve these
# labels from the curated master rather than collapsing both groups to II.
# Their topology is still reported in the validation table, but IIa.A is not
# independently recoverable as a monophyletic clade in both selected trees.
if (preserve_freel_iia) {
  freel_iia_rows <- taxonomy %>%
    filter(
      Clade1 == "II",
      original_Subclade %in% c("IIa.A", "IIa.B")
    ) %>%
    transmute(
      genome,
      Subclade = original_Subclade,
      Family = "Cosmipelagibacteraceae",
      Genus = case_when(
        original_Subclade == "IIa.A" ~ "Anoxypelagibacter",
        original_Subclade == "IIa.B" ~ "Cosmipelagibacter",
        TRUE ~ NA_character_
      ),
      Species = NA_character_,
      Subclade_assignment_source = source_labels[["freel_iia"]],
      Family_assignment_source = source_labels[["freel_iia"]],
      Genus_assignment_source = source_labels[["freel_iia"]],
      Species_assignment_source = NA_character_
    )
  taxonomy <- apply_assignments(taxonomy, freel_iia_rows)
}

# Freel direct subclade and genus evidence is applied to clades I and II.
freel_direct_classification <- prior_freel %>%
  filter(
    Clade1 %in% c("I", "II")
  ) %>%
  transmute(
    genome,
    Subclade = case_when(
      preserve_freel_iia &
        Clade1 == "II" &
        original_Subclade %in% c("IIa.A", "IIa.B") ~
        original_Subclade,
      TRUE ~ subclade_harmonized_freel
    ),
    Family = case_when(
      str_detect(Subclade, "^Ia|^Ib") ~
        "Pelagibacteraceae",
      Subclade == "Ic" ~
        "Mesopelagibacteraceae",
      str_detect(Subclade, "^II") ~
        "Cosmipelagibacteraceae",
      TRUE ~ NA_character_
    ),
    Genus = if_else(
      !is.na(Genus_harmonized_freel) &
        genus_assignment_source %in% c(
          "Freel et al. 2025 Type Strains",
          "Freel et al. 2025 genome",
          "direct_Freel_subclade"
        ),
      Genus_harmonized_freel,
      NA_character_
    ),
    Species = NA_character_,
    direct_source = source_labels[["freel_used"]]
  )

freel_species_direct <- freel_species %>%
  left_join(
    freel_types %>%
      select(
        freel_species_full,
        freel_taxonomic_subclade
    ),
    by = c("species_full_name" = "freel_species_full")
  ) %>%
  left_join(
    meta_original %>%
      select(
        genome,
        master_Clade1 = Clade1,
        master_Subclade = Subclade
      ),
    by = "genome"
  ) %>%
  transmute(
    genome,
    Subclade = case_when(
      preserve_freel_iia &
        master_Clade1 == "II" &
        master_Subclade %in% c("IIa.A", "IIa.B") ~
        master_Subclade,
      freel_taxonomic_subclade %in% c(
        "Ia.3.V", "Ia.3.VI", "Ia.3.VII", "Ia.3.IV", "Ia.3.I",
        "Ia.4.N4", "Ia.4.N1", "Ia.4.II", "Ia.4.N3", "Ia.4.N6",
        "Ia.4.N2", "Ia.4.N5", "Ia.3.III", "Ia.3.II", "Ia.1.I",
        "Ib.N11", "Ib.1.III", "Ib.1", "Ib.2.I", "Ib.N7",
        "Ib.N10", "Ib.4.N8", "Ib.4.I", "Ib.4.N9", "Ic", "II"
      ) ~ freel_taxonomic_subclade,
      TRUE ~ NA_character_
    ),
    Family = freel_family,
    Genus = freel_genus,
    Species = freel_species,
    direct_source = if_else(
      species_assignment_source ==
        source_labels[["freel_type"]],
      source_labels[["freel_type"]],
      source_labels[["freel_used"]]
    )
  )

freel_direct <- full_join(
  freel_direct_classification %>%
    rename_with(
      ~ paste0(.x, "_class"),
      -genome
    ),
  freel_species_direct %>%
    rename_with(
      ~ paste0(.x, "_species"),
      -genome
    ),
  by = "genome"
) %>%
  transmute(
    genome,
    Subclade = coalesce(Subclade_species, Subclade_class),
    Family = coalesce(Family_species, Family_class),
    Genus = coalesce(Genus_species, Genus_class),
    Species = Species_species,
    Subclade_assignment_source = case_when(
      !is.na(Subclade_species) ~ direct_source_species,
      !is.na(Subclade_class) ~ direct_source_class,
      TRUE ~ NA_character_
    ),
    Family_assignment_source = case_when(
      !is.na(Family_species) ~ direct_source_species,
      !is.na(Family_class) ~ direct_source_class,
      TRUE ~ NA_character_
    ),
    Genus_assignment_source = case_when(
      !is.na(Genus_species) ~ direct_source_species,
      !is.na(Genus_class) ~ direct_source_class,
      TRUE ~ NA_character_
    ),
    Species_assignment_source = if_else(
      !is.na(Species_species),
      direct_source_species,
      NA_character_
    )
  )
taxonomy <- apply_assignments(taxonomy, freel_direct)

# Direct matches were extracted from Lanclos et al. Supplementary Table S1.
# Lanclos classified IIIa.1-IIIa.3 as three genus-level lineages but did not
# formally name all three. Only IIIa.1 is linked to a named Freel genus here.
lanclos_direct <- lanclos_matches %>%
  transmute(
    genome,
    Subclade,
    Family = "Fontibacteriaceae",
    Genus = if_else(
      Subclade == "IIIa.1",
      "Elongatipelagibacter",
      NA_character_
    ),
    Species = NA_character_
  ) %>%
  mutate(
    Subclade_assignment_source = source_labels[["lanclos"]],
    Family_assignment_source = source_labels[["lanclos_freel"]],
    Genus_assignment_source = if_else(
      !is.na(Genus),
      source_labels[["lanclos_freel"]],
      NA_character_
    ),
    Species_assignment_source = NA_character_
  )

# Fernandes et al. Supplementary Table 2 assigns all eight Atlas IIIb
# isolates to named Fontibacterium species.
fernandes_direct <- fernandes_matches %>%
  transmute(
    genome,
    Subclade,
    Family = "Fontibacteriaceae",
    Genus,
    Species
  ) %>%
  mutate(
    Subclade_assignment_source = source_labels[["fernandes"]],
    Family_assignment_source = source_labels[["fernandes"]],
    Genus_assignment_source = source_labels[["fernandes"]],
    Species_assignment_source = source_labels[["fernandes"]]
  )

freshwater_direct <- bind_rows(
  lanclos_direct,
  fernandes_direct
)
taxonomy <- apply_assignments(taxonomy, freshwater_direct)

# The requested candidate retains the curated Clade III subgroup scheme.
# Direct Lanclos/Fernandes rows above keep their publication-level sources;
# remaining rows are explicitly marked as curated framework assignments.
# A formal genus is added only where the subgroup-to-genus link is named.
if (preserve_clade_iii) {
  clade_iii_fallback <- taxonomy %>%
    filter(Clade1 == "III") %>%
    transmute(
      genome,
      Subclade = original_Subclade,
      Family = "Fontibacteriaceae",
      Genus = case_when(
        original_Subclade == "IIIa.1" ~
          "Elongatipelagibacter",
        str_detect(original_Subclade, "^IIIb") ~
          "Fontibacterium",
        TRUE ~ NA_character_
      ),
      Species = NA_character_,
      Subclade_assignment_source = source_labels[["curated_iii"]],
      Family_assignment_source = source_labels[["curated_freel_iii"]],
      Genus_assignment_source = if_else(
        !is.na(Genus),
        source_labels[["curated_freel_iii"]],
        NA_character_
      ),
      Species_assignment_source = NA_character_
    )
  taxonomy <- apply_assignments(taxonomy, clade_iii_fallback)
}

ani_long <- ani_matrix %>%
  pivot_longer(
    cols = -genome,
    names_to = "species_reference_genome",
    values_to = "ANI_to_species_reference"
  )

aai_long <- aai_pairs %>%
  transmute(
    genome = `#Genome A`,
    species_reference_genome = `Genome B`,
    AAI_to_species_reference = `Mean AAI`
  ) %>%
  bind_rows(
    aai_pairs %>%
      transmute(
        genome = `Genome B`,
        species_reference_genome = `#Genome A`,
        AAI_to_species_reference = `Mean AAI`
      )
  ) %>%
  group_by(genome, species_reference_genome) %>%
  summarise(
    AAI_to_species_reference = max(
      AAI_to_species_reference,
      na.rm = TRUE
    ),
    .groups = "drop"
  ) %>%
  mutate(
    AAI_to_species_reference = if_else(
      is.infinite(AAI_to_species_reference),
      NA_real_,
      AAI_to_species_reference
    )
  )

species_anchors <- taxonomy %>%
  filter(
    genome %in% sar11_tips,
    !is.na(Species),
    str_detect(
      Species_assignment_source,
      "^Freel et al\\. 2025|^Fernandes et al\\. 2025"
    )
  ) %>%
  transmute(
    species_reference_genome = genome,
    anchor_Clade1 = Clade1,
    anchor_Subclade = Subclade,
    anchor_Family = Family,
    anchor_Genus = Genus,
    anchor_Species = Species,
    species_full_name = paste(Genus, Species)
  )

ani_candidates <- ani_long %>%
  filter(
    genome != species_reference_genome,
    ANI_to_species_reference >= 95
  ) %>%
  inner_join(species_anchors, by = "species_reference_genome") %>%
  left_join(
    taxonomy %>%
      select(genome, candidate_Clade1 = Clade1),
    by = "genome"
  ) %>%
  filter(candidate_Clade1 == anchor_Clade1) %>%
  anti_join(
    taxonomy %>%
      filter(!is.na(Species)) %>%
      select(genome),
    by = "genome"
  ) %>%
  left_join(
    aai_long,
    by = c("genome", "species_reference_genome")
  ) %>%
  filter(
    !is.na(AAI_to_species_reference),
    AAI_to_species_reference >= 95
  ) %>%
  group_by(genome, species_full_name) %>%
  arrange(
    desc(ANI_to_species_reference),
    desc(AAI_to_species_reference),
    .by_group = TRUE
  ) %>%
  slice_head(n = 1) %>%
  ungroup()

ani_ambiguity <- ani_candidates %>%
  distinct(genome, species_full_name) %>%
  count(genome, name = "qualifying_species") %>%
  filter(qualifying_species > 1)

ani_assignments <- ani_candidates %>%
  anti_join(ani_ambiguity, by = "genome") %>%
  group_by(genome) %>%
  arrange(
    desc(ANI_to_species_reference),
    desc(AAI_to_species_reference),
    .by_group = TRUE
  ) %>%
  slice_head(n = 1) %>%
  ungroup() %>%
  transmute(
    genome,
    Subclade = anchor_Subclade,
    Family = anchor_Family,
    Genus = anchor_Genus,
    Species = anchor_Species,
    assignment_source = paste0(
      "ANI>=95% and AAI>=95% with ",
      species_reference_genome
    ),
    species_reference_genome,
    ANI_to_species_reference,
    AAI_to_species_reference
  ) %>%
  mutate(
    Subclade_assignment_source = assignment_source,
    Family_assignment_source = assignment_source,
    Genus_assignment_source = assignment_source,
    Species_assignment_source = assignment_source
  )

taxonomy <- apply_assignments(taxonomy, ani_assignments)
ani_index <- match(taxonomy$genome, ani_assignments$genome)
has_ani <- !is.na(ani_index)
taxonomy$species_reference_genome[has_ani] <-
  ani_assignments$species_reference_genome[ani_index[has_ani]]
taxonomy$ANI_to_species_reference[has_ani] <-
  ani_assignments$ANI_to_species_reference[ani_index[has_ani]]
taxonomy$AAI_to_species_reference[has_ani] <-
  ani_assignments$AAI_to_species_reference[ani_index[has_ani]]

# Primary literature classifications and ANI95/AAI95 assignments define crowns.
# Legacy, curated fallback, and topology-derived labels never seed expansion.
family_seeds <- taxonomy %>%
  transmute(
    genome,
    taxon = Family,
    parent_taxon = NA_character_,
    seed_class = seed_class_from_source(Family_assignment_source)
  ) %>%
  filter(
    !is.na(taxon),
    !is.na(seed_class)
  ) %>%
  distinct()

family_result <- infer_single_tree_assignments(
  taxonomy,
  family_seeds,
  "Family",
  tree_scg165
)

family_topology_evidence <- family_result$assignments %>%
  left_join(
    taxonomy %>%
      select(genome, existing_Family = Family),
    by = "genome"
  ) %>%
  mutate(
    assigned_Family = is.na(existing_Family)
  )

if (nrow(family_topology_evidence) > 0L) {
  family_index <- match(
    taxonomy$genome,
    family_topology_evidence$genome
  )
  family_value <- family_topology_evidence$taxon[family_index]
  family_source <- family_topology_evidence$assignment_source[
    family_index
  ]
  fill_family <- is.na(taxonomy$Family) & !is.na(family_value)
  taxonomy$Family[fill_family] <- family_value[fill_family]
  taxonomy$Family_assignment_source[fill_family] <-
    family_source[fill_family]
}

prior_family_result <- validate_prior_single_seed_families(
  taxonomy,
  meta_original,
  family_seeds,
  tree_scg165
)
prior_family_evidence <- prior_family_result$assignments %>%
  filter(assignment_confidence == "topology_high")
if (nrow(prior_family_evidence) > 0L) {
  prior_family_index <- match(taxonomy$genome, prior_family_evidence$genome)
  prior_family_value <- prior_family_evidence$taxon[prior_family_index]
  prior_family_source <-
    prior_family_evidence$assignment_source[prior_family_index]
  fill_prior_family <- is.na(taxonomy$Family) &
    !is.na(prior_family_value)
  taxonomy$Family[fill_prior_family] <-
    prior_family_value[fill_prior_family]
  taxonomy$Family_assignment_source[fill_prior_family] <-
    prior_family_source[fill_prior_family]
}

# Genus and Subclade are evaluated independently from direct/ANI seeds.
# Their observed direct combinations are used only as a consistency check;
# one rank never creates the other without its own supported crown.
direct_lineage_pairs <- taxonomy %>%
  filter(
    !is.na(Subclade),
    !is.na(Genus),
    !is.na(seed_class_from_source(Subclade_assignment_source)),
    !is.na(seed_class_from_source(Genus_assignment_source))
  ) %>%
  distinct(Subclade, Genus, Family)

subclade_seed_rows <- taxonomy %>%
  transmute(
    genome,
    taxon = Subclade,
    parent_taxon = Family,
    seed_class = seed_class_from_source(Subclade_assignment_source)
  ) %>%
  filter(
    !is.na(taxon),
    !is.na(parent_taxon),
    !is.na(seed_class)
  ) %>%
  distinct()

subclade_result <- infer_single_tree_assignments(
  taxonomy,
  subclade_seed_rows,
  "Subclade",
  tree_scg165
)

subclade_topology_evidence <- subclade_result$assignments %>%
  left_join(
    taxonomy %>%
      select(
        genome,
        existing_Subclade = Subclade,
        existing_Family = Family
      ),
    by = "genome"
  ) %>%
  filter(
    existing_Family == parent_taxon,
    is.na(existing_Subclade) | existing_Subclade == taxon
  ) %>%
  mutate(
    assigned_Subclade = is.na(existing_Subclade)
  )

if (nrow(subclade_topology_evidence) > 0L) {
  subclade_index <- match(
    taxonomy$genome,
    subclade_topology_evidence$genome
  )
  subclade_value <- subclade_topology_evidence$taxon[subclade_index]
  subclade_source <- subclade_topology_evidence$assignment_source[
    subclade_index
  ]

  fill_subclade <- is.na(taxonomy$Subclade) &
    !is.na(subclade_value)
  taxonomy$Subclade[fill_subclade] <-
    subclade_value[fill_subclade]
  taxonomy$Subclade_assignment_source[fill_subclade] <-
    subclade_source[fill_subclade]
}

# A single direct literature match cannot define an MRCA by itself. For such
# taxa, use the preceding harmonized member set only as a candidate crown and
# retain it solely when that complete set is an exact, exclusive SAR11_165
# crown with UFBoot >= 0.95. The source remains topology validation, not a
# direct-paper assignment for the additional genomes.
prior_subclade_result <- validate_prior_single_seed_lineages(
  taxonomy,
  meta_original,
  subclade_seed_rows,
  tree_scg165
)

prior_subclade_evidence <- prior_subclade_result$assignments %>%
  filter(assignment_confidence == "topology_high")

if (nrow(prior_subclade_evidence) > 0L) {
  prior_index <- match(taxonomy$genome, prior_subclade_evidence$genome)
  prior_value <- prior_subclade_evidence$taxon[prior_index]
  prior_parent <- prior_subclade_evidence$parent_taxon[prior_index]
  prior_source <- prior_subclade_evidence$assignment_source[prior_index]
  fill_prior <- is.na(taxonomy$Subclade) &
    !is.na(prior_value) &
    !is.na(taxonomy$Family) &
    !is.na(prior_parent) &
    taxonomy$Family == prior_parent
  taxonomy$Subclade[fill_prior] <- prior_value[fill_prior]
  taxonomy$Subclade_assignment_source[fill_prior] <- prior_source[fill_prior]
}

genus_seeds <- taxonomy %>%
  transmute(
    genome,
    taxon = Genus,
    parent_taxon = Family,
    seed_class = seed_class_from_source(Genus_assignment_source)
  ) %>%
  filter(
    !is.na(taxon),
    !is.na(parent_taxon),
    !is.na(seed_class)
  ) %>%
  distinct()

genus_result <- infer_single_tree_assignments(
  taxonomy,
  genus_seeds,
  "Genus",
  tree_scg165
)

genus_topology_evidence <- genus_result$assignments %>%
  left_join(
    taxonomy %>%
      select(
        genome,
        existing_Genus = Genus,
        existing_Family = Family
      ),
    by = "genome"
  ) %>%
  filter(
    existing_Family == parent_taxon,
    is.na(existing_Genus) | existing_Genus == taxon
  ) %>%
  mutate(assigned_Genus = is.na(existing_Genus))

if (nrow(genus_topology_evidence) > 0L) {
  genus_index <- match(
    taxonomy$genome,
    genus_topology_evidence$genome
  )
  genus_value <- genus_topology_evidence$taxon[genus_index]
  genus_source <- genus_topology_evidence$assignment_source[genus_index]

  fill_genus <- is.na(taxonomy$Genus) &
    !is.na(genus_value)
  taxonomy$Genus[fill_genus] <- genus_value[fill_genus]
  taxonomy$Genus_assignment_source[fill_genus] <-
    genus_source[fill_genus]
}

# Reject topology-derived rank values that form a pair absent from direct data.
lineage_conflicts <- taxonomy %>%
  filter(!is.na(Subclade), !is.na(Genus)) %>%
  anti_join(direct_lineage_pairs, by = c("Subclade", "Genus", "Family"))

if (nrow(lineage_conflicts) > 0L) {
  conflict_index <- match(taxonomy$genome, lineage_conflicts$genome)
  conflict_rows <- !is.na(conflict_index)
  drop_subclade <- conflict_rows &
    taxonomy$Subclade_assignment_source %in% c(
      source_labels[["topology_high"]],
      source_labels[["prior_lineage_high"]]
    )
  drop_genus <- conflict_rows &
    taxonomy$Genus_assignment_source == source_labels[["topology_high"]]
  stopifnot(all(drop_subclade | drop_genus))
  taxonomy$Subclade[drop_subclade] <- NA_character_
  taxonomy$Subclade_assignment_source[drop_subclade] <- NA_character_
  taxonomy$Genus[drop_genus] <- NA_character_
  taxonomy$Genus_assignment_source[drop_genus] <- NA_character_
}

sar11_165_validation <- bind_rows(
  family_result$validation,
  prior_family_result$validation,
  subclade_result$validation,
  prior_subclade_result$validation,
  genus_result$validation
) %>%
  filter(tree == "SAR11_165")

sar11_165_decisions <- bind_rows(
  family_result$decisions,
  subclade_result$decisions,
  genus_result$decisions
) %>%
  transmute(
    genome,
    rank,
    taxon = scg165_taxon,
    parent_taxon = scg165_parent_taxon,
    crown_node = scg165_node,
    crown_support = scg165_support,
    crown_descendants = scg165_descendants,
    target_seeds = scg165_target_seeds,
    primary_seeds = scg165_primary_seeds,
    assignment_confidence,
    decision = if_else(
      !is.na(assignment_confidence),
      "topology_high",
      "no_eligible_SAR11_165_crown"
    )
  )

assignment_confidence_from_source <- function(source) {
  case_when(
    is.na(source) ~ NA_character_,
    source == source_labels[["topology_high"]] ~ "topology_high",
    source == source_labels[["prior_family_high"]] ~ "topology_high",
    source == source_labels[["prior_lineage_high"]] ~ "topology_high",
    str_detect(source, "^ANI>=95% and AAI>=95%") ~ "ANI95_AAI95",
    source == source_labels[["legacy"]] ~ "retained_legacy",
    source == source_labels[["outgroup"]] ~ "retained_outgroup",
    str_detect(source, "^Curated") ~ "retained_curated",
    TRUE ~ "direct_literature"
  )
}

for (rank_name in rank_names) {
  source_name <- paste0(rank_name, "_assignment_source")
  confidence_name <- paste0(rank_name, "_assignment_confidence")
  taxonomy[[confidence_name]] <- assignment_confidence_from_source(
    taxonomy[[source_name]]
  )
}

family_support <- family_topology_evidence %>%
  filter(assigned_Family) %>%
  select(
    genome,
    Family_SAR11_165_crown_node = scg165_node,
    Family_SAR11_165_crown_support = scg165_support
  )

prior_family_support <- prior_family_evidence %>%
  inner_join(
    taxonomy %>% select(genome, current_Family = Family),
    by = "genome"
  ) %>%
  filter(current_Family == taxon) %>%
  select(
    genome,
    Family_SAR11_165_crown_node = scg165_node,
    Family_SAR11_165_crown_support = scg165_support
  )

family_support <- bind_rows(
  family_support,
  prior_family_support
) %>%
  distinct(genome, .keep_all = TRUE)

subclade_support <- subclade_topology_evidence %>%
  filter(assigned_Subclade) %>%
  inner_join(
    taxonomy %>% select(genome, current_Subclade = Subclade),
    by = "genome"
  ) %>%
  filter(current_Subclade == taxon) %>%
  select(
    genome,
    Subclade_SAR11_165_crown_node = scg165_node,
    Subclade_SAR11_165_crown_support = scg165_support
  )

prior_subclade_support <- prior_subclade_evidence %>%
  inner_join(
    taxonomy %>% select(genome, current_Subclade = Subclade),
    by = "genome"
  ) %>%
  filter(current_Subclade == taxon) %>%
  select(
    genome,
    Subclade_SAR11_165_crown_node = scg165_node,
    Subclade_SAR11_165_crown_support = scg165_support
  )

subclade_support <- bind_rows(
  subclade_support,
  prior_subclade_support
) %>%
  distinct(genome, .keep_all = TRUE)

genus_support <- genus_topology_evidence %>%
  filter(assigned_Genus) %>%
  inner_join(
    taxonomy %>% select(genome, current_Genus = Genus),
    by = "genome"
  ) %>%
  filter(current_Genus == taxon) %>%
  select(
    genome,
    Genus_SAR11_165_crown_node = scg165_node,
    Genus_SAR11_165_crown_support = scg165_support
  )

taxonomy <- taxonomy %>%
  left_join(family_support, by = "genome") %>%
  left_join(subclade_support, by = "genome") %>%
  left_join(genus_support, by = "genome")

original_columns <- names(meta_original)
output <- meta_original %>%
  rename(
    original_Subclade = Subclade,
    original_Subgroup = Subgroup,
    original_Family = Family,
    original_Genus = Genus,
    original_Species = Species
  ) %>%
  left_join(
    taxonomy %>%
      select(
        genome,
        Subclade,
        Family,
        Genus,
        Species,
        all_of(source_names),
        all_of(confidence_names),
        ends_with("_crown_node"),
        ends_with("_crown_support"),
        species_reference_genome,
        ANI_to_species_reference,
        AAI_to_species_reference
      ),
    by = "genome"
  ) %>%
  mutate(
    Subgroup = case_when(
      Clade1 == "outgroup" ~ original_Subgroup,
      !is.na(Subclade) ~ Subclade,
      TRUE ~ NA_character_
    )
  ) %>%
  relocate(
    Subclade,
    Subgroup,
    Family,
    Genus,
    Species,
    .after = Clade2
  ) %>%
  relocate(
    starts_with("original_"),
    all_of(source_names),
    all_of(confidence_names),
    ends_with("_crown_node"),
    ends_with("_crown_support"),
    species_reference_genome,
    ANI_to_species_reference,
    AAI_to_species_reference,
    .after = last_col()
  )

ani_source_rows <- which(
  coalesce(
    str_detect(
      output$Species_assignment_source,
      "^ANI>=95% and AAI>=95%"
    ),
    FALSE
  )
)

stopifnot(
  nrow(output) == 562L,
  !anyDuplicated(output$genome),
  sum(output$Clade1 != "outgroup") == 542L,
  sum(!is.na(output$Genus) & is.na(output$Family)) == 0L,
  sum(!is.na(output$Species) & is.na(output$Genus)) == 0L,
  sum(!is.na(output$Species) & is.na(output$Family)) == 0L,
  all(
    output$Species_assignment_source[ani_source_rows] ==
      output$Subclade_assignment_source[ani_source_rows]
  ),
  !any(
    output$Family_assignment_confidence == "topology_provisional",
    na.rm = TRUE
  ),
  !any(
    output$Genus_assignment_confidence == "topology_provisional",
    na.rm = TRUE
  ),
  !any(
    output$Subclade_assignment_confidence == "topology_provisional",
    na.rm = TRUE
  ),
  all(
    output$Family_SAR11_165_crown_support >= topology_high_support,
    na.rm = TRUE
  ),
  all(
    output$Genus_SAR11_165_crown_support >= topology_high_support,
    na.rm = TRUE
  ),
  all(
    output$Subclade_SAR11_165_crown_support >= topology_high_support,
    na.rm = TRUE
  )
)

audit <- output %>%
  select(
    genome,
    Clade1,
    type,
    Subclade,
    Family,
    Genus,
    Species,
    starts_with("original_"),
    all_of(source_names),
    all_of(confidence_names),
    ends_with("_crown_node"),
    ends_with("_crown_support"),
    species_reference_genome,
    ANI_to_species_reference,
    AAI_to_species_reference
  )

source_summary <- bind_rows(
  lapply(rank_names, function(rank_name) {
    source_name <- paste0(rank_name, "_assignment_source")
    output %>%
      filter(Clade1 != "outgroup") %>%
      count(
        assignment_source = .data[[source_name]],
        name = "genomes"
      ) %>%
      mutate(rank = rank_name, .before = 1)
  })
)

assignment_summary <- tibble(
  metric = c(
    "atlas_rows",
    "sar11_genomes",
    "subclade_assigned",
    "family_assigned",
    "genus_assigned",
    "species_assigned",
    "ANI95_AAI95_assignments",
    "ANI95_AAI95_ambiguous_genomes",
    "topology_high_family_assignments",
    "topology_high_genus_assignments",
    "topology_high_subclade_assignments"
  ),
  value = c(
    nrow(output),
    sum(output$Clade1 != "outgroup"),
    sum(!is.na(output$Subclade) & output$Clade1 != "outgroup"),
    sum(!is.na(output$Family) & output$Clade1 != "outgroup"),
    sum(!is.na(output$Genus) & output$Clade1 != "outgroup"),
    sum(!is.na(output$Species) & output$Clade1 != "outgroup"),
    nrow(ani_assignments),
    nrow(ani_ambiguity),
    sum(
      output$Family_assignment_confidence == "topology_high",
      na.rm = TRUE
    ),
    sum(
      output$Genus_assignment_confidence == "topology_high",
      na.rm = TRUE
    ),
    sum(
      output$Subclade_assignment_confidence == "topology_high",
      na.rm = TRUE
    )
  )
)

classification_changes <- output %>%
  filter(Clade1 != "outgroup") %>%
  transmute(
    genome,
    Clade1,
    original_Subclade,
    harmonized_Subclade = Subclade,
    original_Family,
    harmonized_Family = Family,
    original_Genus,
    harmonized_Genus = Genus,
    original_Species,
    harmonized_Species = Species,
    subclade_changed = coalesce(
      original_Subclade != Subclade,
      xor(is.na(original_Subclade), is.na(Subclade))
    ),
    family_changed = coalesce(
      original_Family != Family,
      xor(is.na(original_Family), is.na(Family))
    ),
    genus_changed = coalesce(
      original_Genus != Genus,
      xor(is.na(original_Genus), is.na(Genus))
    ),
    species_changed = coalesce(
      original_Species != Species,
      xor(is.na(original_Species), is.na(Species))
    )
  ) %>%
  filter(
    subclade_changed |
      family_changed |
      genus_changed |
      species_changed
  )

source_manifest <- tribble(
  ~assignment_source, ~reference, ~url, ~application,
  source_labels[["freel_type"]],
  "Freel et al. (2025), Nature Communications",
  "https://doi.org/10.1038/s41467-025-67043-6",
  "Direct type-strain taxonomy and named species",
  source_labels[["freel_used"]],
  "Freel et al. (2025), Nature Communications",
  "https://doi.org/10.1038/s41467-025-67043-6",
  "Direct genomes used in the Freel classification and Supplementary Data 5",
  source_labels[["freel_iia"]],
  "Freel et al. (2025), Nature Communications",
  "https://doi.org/10.1038/s41467-025-67043-6",
  "Preserved IIa.A and IIa.B labels from the curated Freel-aligned master",
  source_labels[["fernandes"]],
  "Fernandes et al. (2025), Nature Microbiology",
  "https://doi.org/10.1038/s41564-025-02091-8",
  "Direct Fontibacterium genome, subclade, genus, and species assignments",
  source_labels[["lanclos"]],
  "Lanclos et al. (2023), The ISME Journal",
  "https://doi.org/10.1038/s41396-023-01376-2",
  "Direct SAR11-IIIa genome and subgroup assignments",
  source_labels[["lanclos_freel"]],
  "Lanclos et al. (2023) and Freel et al. (2025)",
  paste(
    "https://doi.org/10.1038/s41396-023-01376-2",
    "https://doi.org/10.1038/s41467-025-67043-6",
    sep = "; "
  ),
  "Lanclos IIIa subgroup linked to the corresponding Freel family/genus name",
  source_labels[["curated_iii"]],
  "Curated SAR11 Genome Atlas classification",
  meta_path,
  "Retained Clade III subgroup for genomes absent from the source-paper tables",
  source_labels[["curated_freel_iii"]],
  "Curated Atlas classification and Freel et al. (2025)",
  paste(
    meta_path,
    "https://doi.org/10.1038/s41467-025-67043-6",
    sep = "; "
  ),
  "Curated Clade III subgroup linked to a named Freel family/genus",
  "ANI>=95% and AAI>=95% with <strain>",
  "Atlas all-vs-all ANI and AAI results",
  paste(
    "data/phylogeny/fastani_SAR11_542_symmetric_matrix.tsv",
    "data/phylogeny/comparem_aaiwf_SAR11_542_out_summary.tsv",
    sep = "; "
  ),
  paste(
    "Species and associated taxonomy propagation from a unique direct",
    "species reference supported by both ANI and AAI"
  ),
  source_labels[["topology_high"]],
  scg165_tree_label,
  scg165_tree_path,
  paste(
    "Genome-specific interpolation within SAR11_165 seed-bounded",
    "crowns; crown support >= 0.95"
  ),
  source_labels[["prior_family_high"]],
  scg165_tree_label,
  scg165_tree_path,
  paste(
    "Validation of an existing single-seed Family only when the complete",
    "prior candidate set is the exact exclusive SAR11_165 crown;",
    "crown support >= 0.95"
  ),
  source_labels[["prior_lineage_high"]],
  scg165_tree_label,
  scg165_tree_path,
  paste(
    "Validation of an existing single-seed Genus/Subclade only when the",
    "complete prior candidate set is the exact exclusive SAR11_165 crown,",
    "its parent Family is consistent, and crown support >= 0.95"
  )
)

write_tsv(
  output,
  file.path(output_dir, "subclade_harmonized.tsv"),
  na = "NA"
)
write_tsv(
  audit,
  file.path(output_dir, "subclade_harmonized_audit.tsv"),
  na = "NA"
)
write_tsv(
  sar11_165_validation,
  file.path(output_dir, validation_filename),
  na = "NA"
)
write_tsv(
  sar11_165_decisions,
  file.path(output_dir, "sar11_165_assignment_decisions.tsv"),
  na = "NA"
)
write_tsv(
  ani_assignments,
  file.path(output_dir, "ANI95_AAI95_species_assignments.tsv"),
  na = "NA"
)
write_tsv(
  ani_ambiguity,
  file.path(output_dir, "ANI95_AAI95_assignment_ambiguity.tsv"),
  na = "NA"
)
write_tsv(
  freshwater_direct,
  file.path(output_dir, "freshwater_direct_evidence.tsv"),
  na = "NA"
)
write_tsv(
  freel_direct,
  file.path(output_dir, "freel_direct_evidence.tsv"),
  na = "NA"
)
write_tsv(
  source_manifest,
  file.path(output_dir, "taxonomy_source_manifest.tsv"),
  na = "NA"
)
write_tsv(
  source_summary,
  file.path(output_dir, "assignment_source_summary.tsv"),
  na = "NA"
)
write_tsv(
  assignment_summary,
  file.path(output_dir, "harmonization_summary.tsv"),
  na = "NA"
)
write_tsv(
  classification_changes,
  file.path(
    output_dir,
    "classification_changes_vs_previous_promoted.tsv"
  ),
  na = "NA"
)

family_colors <- c(
  "Pelagibacteraceae" = "#3B82C4",
  "Cosmipelagibacteraceae" = "#E69F35",
  "Mesopelagibacteraceae" = "#4FA866",
  "Fontibacteriaceae" = "#B0649A",
  "Unassigned" = "#C8CDD2"
)

plot_tree_review <- function(tree, title, output) {
  family_by_tip <- output$Family[
    match(tree$tip.label, output$genome)
  ]
  family_by_tip[is.na(family_by_tip)] <- "Unassigned"
  plot(
    tree,
    type = "fan",
    show.tip.label = FALSE,
    edge.color = "#66727C",
    edge.width = 0.35,
    no.margin = TRUE
  )
  tiplabels(
    pch = 16,
    col = family_colors[family_by_tip],
    cex = 0.22
  )
  title(main = title, cex.main = 1)
}

pdf(
  file.path(output_dir, "harmonized_taxonomy_SAR11_165_review.pdf"),
  width = 7,
  height = 7
)
par(mar = c(1, 1, 3, 1))
plot_tree_review(tree_scg165, scg165_tree_label, output)
par(xpd = NA)
legend(
  "bottom",
  inset = -0.08,
  legend = names(family_colors),
  col = family_colors,
  pch = 16,
  horiz = TRUE,
  bty = "n",
  cex = 0.8
)
dev.off()

message("Harmonized taxonomy written to: ", output_dir)
print(assignment_summary, n = Inf)
