suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
})

phylogeny_dir <- "data/phylogeny"
candidate_path <- Sys.getenv(
  "HARMONIZED_CANDIDATE_PATH",
  unset = file.path(
    phylogeny_dir,
    "taxonomy_harmonization",
    "outputs",
    "final_sar11_165_iqtree_high_support",
    "subclade_harmonized.tsv"
  )
)
master_path <- file.path(phylogeny_dir, "subclade_master.tsv")
cat_path <- file.path(phylogeny_dir, "subclade_cat.tsv")
table_path <- file.path(phylogeny_dir, "subclade.txt")
tree_annotation_path <- file.path(
  phylogeny_dir,
  "tree",
  "tree_annottable_ogpage_542.tsv"
)
overview_summary_path <- file.path(
  "data",
  "overview",
  "genome_summary.tsv"
)
archive_dir <- file.path(
  "tmp",
  "taxonomy_archive",
  "old_subclade_classification",
  "pre_single_SAR11_165_2026-08-10"
)

current_paths <- c(master_path, cat_path, table_path)
stopifnot(
  file.exists(candidate_path),
  all(file.exists(current_paths)),
  file.exists(tree_annotation_path),
  file.exists(overview_summary_path)
)

candidate <- read_tsv(
  candidate_path,
  col_types = cols(.default = col_character()),
  na = "NA"
)

required_columns <- c(
  "genome", "Clade1", "Clade2", "Subclade", "Subgroup",
  "Order", "Family", "Genus", "Species", "reference",
  "type_strain_Freel_2024", "type", "depth", "latitude",
  "longitude", "depth_cat", "latitude_cat", "longhurst_code",
  "description", "habitat_type", "waterbody_name", "habitat_source"
)

stopifnot(
  all(required_columns %in% names(candidate)),
  nrow(candidate) == 562L,
  !anyDuplicated(candidate$genome),
  sum(candidate$Clade1 == "outgroup", na.rm = TRUE) == 20L,
  sum(candidate$Clade1 != "outgroup", na.rm = TRUE) == 542L
)

if (!dir.exists(archive_dir)) {
  dir.create(archive_dir, recursive = TRUE, showWarnings = FALSE)
  copied <- file.copy(
    current_paths,
    file.path(archive_dir, basename(current_paths)),
    overwrite = FALSE,
    copy.mode = TRUE,
    copy.date = TRUE
  )
  stopifnot(all(copied))
} else {
  stopifnot(all(file.exists(file.path(
    archive_dir,
    basename(current_paths)
  ))))
}

# Legacy labels remain in the archive and internal audit outputs only.
public_candidate <- candidate %>%
  select(-starts_with("original_"))

write_tsv(
  public_candidate,
  master_path,
  na = "NA"
)

cat_columns <- c(
  "genome", "Clade1", "Clade2", "Subclade", "Subgroup",
  "Order", "Family", "Genus", "Species", "reference",
  "type_strain_Freel_2024", "type", "depth_cat", "latitude_cat",
  "longhurst_code", "description", "habitat_type", "waterbody_name",
  "habitat_source"
)

table_columns <- c(
  "genome", "Clade1", "Clade2", "Subclade", "Subgroup",
  "Order", "Family", "Genus", "Species", "reference",
  "type_strain_Freel_2024", "type", "depth", "latitude", "longitude",
  "longhurst_code", "description", "habitat_type", "waterbody_name",
  "habitat_source"
)

write_tsv(
  public_candidate %>% select(all_of(cat_columns)),
  cat_path,
  na = "NA"
)
write_tsv(
  public_candidate %>% select(all_of(table_columns)),
  table_path,
  na = "NA"
)

tree_og_columns <- read_tsv(
  tree_annotation_path,
  col_select = c(genome, starts_with("OG")),
  col_types = cols(.default = col_character()),
  na = "NA",
  show_col_types = FALSE,
  progress = FALSE
)
stopifnot(
  nrow(tree_og_columns) == 562L,
  !anyDuplicated(tree_og_columns$genome),
  setequal(tree_og_columns$genome, public_candidate$genome)
)

tree_annotation <- tree_og_columns %>%
  select(genome) %>%
  left_join(
    public_candidate %>% select(all_of(cat_columns)),
    by = "genome"
  ) %>%
  left_join(tree_og_columns, by = "genome") %>%
  select(all_of(cat_columns), starts_with("OG"))

write_tsv(
  tree_annotation,
  tree_annotation_path,
  na = "NA"
)

overview_summary <- read_tsv(
  overview_summary_path,
  show_col_types = FALSE,
  progress = FALSE,
  na = "NA"
)
overview_metadata <- public_candidate %>%
  filter(Clade1 != "outgroup") %>%
  transmute(
    genome_id = genome,
    clade_1 = Clade1,
    clade_2 = Clade2,
    subclade = Subclade,
    subgroup = Subgroup,
    Order,
    Family,
    Genus,
    Species,
    reference,
    type_strain_Freel_2024,
    genome_type = type,
    depth,
    latitude,
    longitude,
    depth_cat,
    latitude_cat,
    longhurst_code,
    description,
    habitat_type,
    waterbody_name,
    habitat_source
  )
stopifnot(
  nrow(overview_summary) == 542L,
  !anyDuplicated(overview_summary$genome_id),
  setequal(overview_summary$genome_id, overview_metadata$genome_id)
)

overview_index <- match(
  overview_summary$genome_id,
  overview_metadata$genome_id
)
for (column_name in setdiff(names(overview_metadata), "genome_id")) {
  overview_summary[[column_name]] <-
    overview_metadata[[column_name]][overview_index]
}

write_tsv(
  overview_summary,
  overview_summary_path,
  na = "NA"
)

message("Archived legacy classification: ", archive_dir)
message("Promoted master: ", master_path)
message("Regenerated Taxonium metadata: ", cat_path)
message("Regenerated searchable metadata: ", table_path)
message("Regenerated OG-viewer tree metadata: ", tree_annotation_path)
message("Synchronized Overview genome metadata: ", overview_summary_path)
