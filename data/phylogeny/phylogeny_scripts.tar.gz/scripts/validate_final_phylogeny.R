suppressPackageStartupMessages({
  library(ape)
  library(dplyr)
  library(readr)
  library(stringr)
})

phylogeny_dir <- "data/phylogeny"
tree_dir <- file.path(phylogeny_dir, "tree")
output_dir <- file.path(
  phylogeny_dir,
  "taxonomy_harmonization",
  "outputs",
  "final_dual_iqtree"
)

metadata <- read_tsv(
  file.path(phylogeny_dir, "subclade_master.tsv"),
  show_col_types = FALSE,
  na = "NA"
)
outgroup_tips <- metadata$genome[metadata$Clade1 == "outgroup"]
sar11_tips <- metadata$genome[metadata$Clade1 != "outgroup"]

tree_paths <- c(
  "bac120 IQ-TREE 2" = file.path(
    tree_dir,
    "SAR11_542_bac120_iqtree.tree"
  ),
  "SAR11_165 IQ-TREE 2" = file.path(
    tree_dir,
    "SAR11_542_SCG165_iqtree.tree"
  )
)

extract_ufboot <- function(label) {
  suppressWarnings(as.numeric(str_extract(label, "[0-9.]+$")))
}

root_and_validate <- function(path) {
  tree <- read.tree(path)
  stopifnot(
    Ntip(tree) == 562L,
    !anyDuplicated(tree$tip.label),
    setequal(tree$tip.label, c(sar11_tips, outgroup_tips)),
    is.monophyletic(tree, outgroup_tips, reroot = TRUE)
  )
  rooted <- root(tree, outgroup = outgroup_tips, resolve.root = TRUE)
  sar11_tree <- keep.tip(rooted, sar11_tips)
  stopifnot(
    is.rooted(rooted),
    is.rooted(sar11_tree),
    Ntip(sar11_tree) == 542L,
    setequal(sar11_tree$tip.label, sar11_tips)
  )
  list(full = rooted, sar11 = sar11_tree)
}

trees <- lapply(tree_paths, root_and_validate)

family_groups <- metadata %>%
  filter(Clade1 != "outgroup") %>%
  mutate(
    family_group = case_when(
      !is.na(Family) ~ Family,
      Clade1 == "IV" ~ "Family-unassigned Clade IV",
      TRUE ~ NA_character_
    )
  ) %>%
  filter(!is.na(family_group)) %>%
  group_by(family_group) %>%
  summarise(
    tips = list(genome),
    genomes = n(),
    .groups = "drop"
  )

family_summary <- bind_rows(lapply(names(trees), function(tree_name) {
  tree <- trees[[tree_name]]$full
  family_groups %>%
    rowwise() %>%
    mutate(
      marker_tree = tree_name,
      monophyletic = is.monophyletic(tree, tips),
      mrca_node = if (genomes > 1L) getMRCA(tree, tips) else NA_integer_,
      node_label = if (!is.na(mrca_node)) {
        tree$node.label[mrca_node - Ntip(tree)]
      } else {
        NA_character_
      },
      ufboot = extract_ufboot(node_label)
    ) %>%
    ungroup() %>%
    select(
      marker_tree,
      family_group,
      genomes,
      monophyletic,
      mrca_node,
      node_label,
      ufboot
    )
}))

get_descendant_tips <- function(tree, node) {
  if (node <= Ntip(tree)) {
    return(tree$tip.label[node])
  }
  extract.clade(tree, node)$tip.label
}

relationship_summary <- bind_rows(lapply(names(trees), function(tree_name) {
  tree <- trees[[tree_name]]$full
  meso_tips <- metadata$genome[
    metadata$Family == "Mesopelagibacteraceae" &
      !is.na(metadata$Family)
  ]
  cosmi_tips <- metadata$genome[
    metadata$Family == "Cosmipelagibacteraceae" &
      !is.na(metadata$Family)
  ]
  combined_node <- getMRCA(tree, c(meso_tips, cosmi_tips))
  combined_tips <- get_descendant_tips(tree, combined_node)
  combined_families <- metadata %>%
    filter(genome %in% combined_tips) %>%
    distinct(Family) %>%
    pull(Family) %>%
    na.omit() %>%
    sort()
  node_label <- tree$node.label[combined_node - Ntip(tree)]

  tibble(
    marker_tree = tree_name,
    mesopelagibacteraceae_genomes = length(meso_tips),
    cosmipelagibacteraceae_genomes = length(cosmi_tips),
    combined_crown_genomes = length(combined_tips),
    combined_crown_families = paste(combined_families, collapse = ";"),
    sister_lineages = setequal(
      combined_families,
      c("Cosmipelagibacteraceae", "Mesopelagibacteraceae")
    ),
    combined_crown_node = combined_node,
    node_label,
    ufboot = extract_ufboot(node_label)
  )
}))

default_tree <- read.tree(file.path(
  tree_dir,
  "SAR11_542_SCG165_iqtree_rooted_SAR11_only.tree"
))
stopifnot(
  is.rooted(default_tree),
  Ntip(default_tree) == 542L,
  !anyDuplicated(default_tree$tip.label),
  setequal(default_tree$tip.label, sar11_tips),
  !any(default_tree$tip.label %in% outgroup_tips)
)

dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
write_tsv(
  family_summary,
  file.path(output_dir, "dual_iqtree_family_monophyly.tsv"),
  na = "NA"
)
write_tsv(
  relationship_summary,
  file.path(output_dir, "dual_iqtree_family_relationship.tsv"),
  na = "NA"
)

message("Final phylogeny validation passed.")
print(family_summary)
print(relationship_summary)
